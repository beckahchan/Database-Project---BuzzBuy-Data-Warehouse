<!DOCTYPE html>
<html>
<head>
    <title>BuzzBuy Data Warehouse</title>
    <meta charset="utf-8">
    <link rel = "stylesheet" href="./table.css" />
</head>
<body>
    <header>
        <h1>BuzzBuy Data Warehouse</h1> <br>
    </header>
    <div style="text-align:center"> <a href="./index.php" class="submit"> Main Menu </a> </div> <br> 
