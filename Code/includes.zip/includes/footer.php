
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="utf-8">
    <style>
        p{
            font-size: 1.2em;
            padding: 1px 15px;
            text-align: center;
            text-decoration: none;
            display: block; 
        }
    </style> 
</head>
<body>

    <footer>
        <p>Built by team 11 in July 2024. 
           Awesome people in team 11: Beckah Ming-Wai Chan, Yan Cheng, Celeste Renae Elam, Jeffrey Ng, Roberto E Sarabia
        </p>
   </footer>

    <main>